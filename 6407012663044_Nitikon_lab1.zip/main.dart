import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "My Flutter App",
      home: Scaffold(
         backgroundColor: Color.fromARGB(255, 63, 63, 63),
        appBar: AppBar(
          actions: [
            Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 5, 0),
              child: Icon(
                Icons.search,
                size: 40,
                color: Color.fromARGB(255, 230, 230, 230),
              ),
            )
          ],
          leading: Icon(
            Icons.arrow_back,
            color: Color.fromARGB(255, 255, 255, 255),
            size: 40,
          ),
          backgroundColor: Color.fromARGB(255, 0, 10, 156),
          title: const Text('My Profile UI'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Color.fromARGB(255, 255, 255, 255),
                    width: 4.0,
                  ),
                ),
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                    'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
                  ),
                ),
              ),

              const Divider(
                height: 60.0,
                color: Color.fromARGB(136, 255, 255, 255),
              ),

              const Text(
                'NAME',
                style: TextStyle(
                  fontFamily: 'Raleway',
                  color: Colors.white70,
                  letterSpacing: 2.0,
                )
              ),
              const SizedBox(
                height: 5.0,
              ),
              const Text(
                'Nitikon Silisopoubpun',
                style: TextStyle(
                  fontFamily: 'Raleway',
                  color: Color.fromARGB(255, 255, 255, 255),
                  letterSpacing: 2.0,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const Text(
                'POSITION',
                style: TextStyle(
                  fontFamily: 'Raleway',
                  color: Colors.white70,
                  letterSpacing: 2.0,
                )
              ),
              const SizedBox(
                height: 5.0,
              ),
              const Text(
                'Student of King Mongkut University of Technology North Bangkok',
                style: TextStyle(
                  fontFamily: 'Raleway',
                  color: Color.fromARGB(255, 255, 255, 255),
                  letterSpacing: 2.0,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),

              SizedBox(height: 16),
              ListTile(
                leading: Icon(Icons.email),
                iconColor: Colors.white,
                title: Text('leng0987@gmail.com'),
                textColor: Colors.white,
              ),
            ],
          ),
        ),
      ),
    );
  }
}